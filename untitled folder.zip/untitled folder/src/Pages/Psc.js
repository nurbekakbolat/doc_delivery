import React from "react";

function Psc() {
  return <div></div>;
}

export default Psc;
